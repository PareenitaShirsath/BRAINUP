package com.example.brainup;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class BrainupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brainup);

        CardView timer = findViewById(R.id.cardTimer);
        timer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(BrainupActivity.this,TimerActivity.class);
                it.putExtra("title","Timer");
                startActivity(it);
            }
        });
        CardView music = findViewById(R.id.cardMusic);
        music.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent it = new Intent(BrainupActivity.this,PlayerActivity.class);
                it.putExtra("title","Music");
                startActivity(it);

            }
        });
        CardView game = findViewById(R.id.cardGame);
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(BrainupActivity.this,AddPlayers.class);
                it.putExtra("title","Game");
                startActivity(it);
            }
        });
    }
}