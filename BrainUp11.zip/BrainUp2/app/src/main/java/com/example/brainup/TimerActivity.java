package com.example.brainup;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class TimerActivity extends AppCompatActivity {

  private int duration = 3600;
  private boolean timerRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        final TextView hour = findViewById(R.id.hour);
        final TextView minute = findViewById(R.id.minute);
        final TextView second = findViewById(R.id.second);
        final AppCompatButton startBtn = findViewById(R.id.startBtn);

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!timerRunning){
                    timerRunning = true;
                    new CountDownTimer(duration * 1000, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String time = String.format(Locale.getDefault(), "%02d:%02d:%02d", TimeUnit.MILLISECONDS.toHours(millisUntilFinished),
                                        TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)-
                                        TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
                                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)-
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished)), Locale.getDefault());

                                final String[] hourMinSec = time.split(":");
                                hour.setText(hourMinSec[0]);
                                minute.setText(hourMinSec[1]);
                                second.setText(hourMinSec[2]);

                            }
                        });
                    }

                    @Override
                    public void onFinish() {
                        duration = 3600;
                        timerRunning = false;
                    }
                }.start();

                }else {
                    Toast.makeText(TimerActivity.this,"Timmer is already running", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }}
